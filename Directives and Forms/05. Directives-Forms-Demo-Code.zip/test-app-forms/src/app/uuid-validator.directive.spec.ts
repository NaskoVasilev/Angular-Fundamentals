import { UuidValidatorDirective } from './uuid-validator.directive';

describe('UuidValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new UuidValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
