export const APP_KEY = '' // Kinvey APP KEY here;
export const APP_SECRET = '' // Kinvey APP SECRET here;