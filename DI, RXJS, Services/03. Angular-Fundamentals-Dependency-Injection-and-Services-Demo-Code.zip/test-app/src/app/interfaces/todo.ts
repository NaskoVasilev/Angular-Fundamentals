export interface ITodo {
  title: string;
  completed: boolean;
}
