import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { PostService } from 'src/app/core/services/post.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-create',
  templateUrl: './post-create.component.html',
  styleUrls: ['./post-create.component.css']
})
export class PostCreateComponent {
  @ViewChild('f') creatPostForm: NgForm;

  constructor(
    private postService: PostService,
    private router: Router
  ) { }


  createPost() {
    const body = this.creatPostForm.value;
    body['author'] = localStorage.getItem('username');

    this.postService.createPost(body)
      .subscribe(() => {
        this.router.navigate([ '/posts' ]);
      })
  }
}
